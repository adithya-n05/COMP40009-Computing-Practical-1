import java.net.URL;

/**
 * Created by David on 28/03/2016.
 */
public class Fetcher {
    public byte[] fetch(URL url) {
        return new byte[0];
    }
}
