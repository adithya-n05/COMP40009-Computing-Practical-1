/**
 * Created by David on 28/03/2016.
 */
public class URLFetcher extends Fetcher {
}
