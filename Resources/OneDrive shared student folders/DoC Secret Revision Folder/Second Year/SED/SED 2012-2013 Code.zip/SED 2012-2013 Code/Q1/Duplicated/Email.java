/**
 * Created by David on 28/03/2016.
 */
public class Email {
    public Email(String s, String message) {
    }

    public void send() {
    }
}
