/**
 * Created by David on 28/03/2016.
 */
public class Sms {
    public Sms(String message) {

    }

    public void send(String s) {

    }
}
