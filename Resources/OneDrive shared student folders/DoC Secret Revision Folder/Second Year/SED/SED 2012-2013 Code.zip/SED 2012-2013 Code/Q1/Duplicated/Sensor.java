/**
 * Created by David on 28/03/2016.
 */
public interface Sensor {
    boolean active();
    double level();
    String description();
}
