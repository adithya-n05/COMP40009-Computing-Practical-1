/**
 * Created by David on 28/03/2016.
 */
public interface MoniteringSystem {
    Sensor[] allSensors();
}
