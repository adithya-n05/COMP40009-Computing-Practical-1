from ElvisVisitor import ElvisVisitor
from ElvisParser  import ElvisParser

class Interpreter(ElvisVisitor):
  memory = {}

  def visitPrintExpr(self, ctx):
    value = self.visit(ctx.expr())
    print(value)
    return 0

  def visitId(self, ctx):
    id = ctx.ID().getText()
    if id in self.memory:
      return self.memory[id]
    return 0

  def visitInt(self, ctx):
    return int(ctx.INT().getText())

  def visitAssign(self, ctx):
    id = ctx.ID().getText()
    value = self.visit(ctx.expr())
    self.memory[id] = value
    return value

  def visitMulDiv(self, ctx):
    left = self.visit(ctx.expr(0))
    right = self.visit(ctx.expr(1))
    if ctx.op.type == ElvisParser.MUL:
      return left * right
    return left / right

  def visitAddSub(self, ctx):
    left = self.visit(ctx.expr(0))
    right = self.visit(ctx.expr(1))
    if ctx.op.type == ElvisParser.ADD:
      return left + right
    return left - right

  def visitParens(self, ctx):
    return self.visit(ctx.expr())

