
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class RocknRoll {

  public static void main(String[] args) throws Exception {

    // create a CharStream that reads from standard input
    ANTLRInputStream input = new ANTLRInputStream(System.in); 

    // create a lexer that reads from the input CharStream
    ElvisLexer lexer = new ElvisLexer(input); 

    // create a buffer of tokens read from the lexer
    CommonTokenStream tokens = new CommonTokenStream(lexer); 

    // create a parser that reads from the tokens buffer 
    ElvisParser parser = new ElvisParser(tokens); 

    // begin parsing at prog rule
    ParseTree tree = parser.prog();

    // print a LISP-style parse tree
    System.out.println(tree.toStringTree(parser)); 
  }

  public static void main2(String[] args) throws Exception {
    // Functional style
    ElvisParser parser = new ElvisParser(
                           new CommonTokenStream(
                             new ElvisLexer(
                               new ANTLRInputStream(System.in))));

    System.out.println(parser.prog().toStringTree(parser));
  }

}
