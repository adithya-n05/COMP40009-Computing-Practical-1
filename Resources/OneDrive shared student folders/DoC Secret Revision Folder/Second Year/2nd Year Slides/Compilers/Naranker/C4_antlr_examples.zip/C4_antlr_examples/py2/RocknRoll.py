
from antlr4 import *
from ElvisLexer  import ElvisLexer
from ElvisParser import ElvisParser

def main(argv):
  input = FileStream(argv[1])
  lexer = ElvisLexer(input)
  stream = CommonTokenStream(lexer)
  parser = ElvisParser(stream)
  tree = parser.prog()

  print(tree.toStringTree(recog=parser))

def main2(argv):   # Functional style
  parser = ElvisParser(CommonTokenStream(ElvisLexer(FileStream(argv[1]))));
  print(parser.prog().toStringTree(recog=parser))

if __name__ == '__main__':
  import sys
  main(sys.argv)
