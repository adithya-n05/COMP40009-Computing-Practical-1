
from antlr4 import *
from ElvisLexer  import ElvisLexer
from ElvisParser import ElvisParser
from Interpreter import Interpreter

def main(argv):   
  parser = ElvisParser(CommonTokenStream(ElvisLexer(FileStream(argv[1]))));
  tree = parser.prog ()

  interpreter = Interpreter()
  interpreter.visit(tree)      # or interpreter.visitProg(tree)

if __name__ == '__main__':
  import sys
  main(sys.argv)
