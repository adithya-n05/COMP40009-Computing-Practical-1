
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

public class RocknRoll {

 public static void main(String[] args) throws Exception {
  
  // Functional style
  ElvisParser parser = new ElvisParser(
                         new CommonTokenStream(
                           new ElvisLexer(
                             new ANTLRInputStream(System.in))));

  ParseTree tree = parser.prog();  	// parse

  Interpreter interpreter = new Interpreter();
  interpreter.visit(tree);		// interpret
 }
}
