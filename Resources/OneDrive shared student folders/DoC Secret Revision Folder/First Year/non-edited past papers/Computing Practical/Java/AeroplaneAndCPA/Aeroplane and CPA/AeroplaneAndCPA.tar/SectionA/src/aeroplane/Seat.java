package aeroplane;

public class Seat {

	// TODO: Section A, Tasks 1 and 3
	
}
