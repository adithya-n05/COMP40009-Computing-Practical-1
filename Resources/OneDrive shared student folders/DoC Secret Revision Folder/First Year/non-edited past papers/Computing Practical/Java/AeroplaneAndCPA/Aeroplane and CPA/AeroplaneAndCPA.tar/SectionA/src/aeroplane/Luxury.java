package aeroplane;

public enum Luxury {

	CHAMPAGNE, TRUFFLES, STRAWBERRIES;
	
	@Override
	public String toString() {
		return super.toString().toLowerCase();
	}
	
}
