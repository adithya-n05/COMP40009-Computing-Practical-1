public interface GraphInterface{

	public int getEarliestCompletionTime() throws GraphException;

}

