package aeroplane;

public abstract class Passenger {

	// TODO: Section A, Task 2
}
