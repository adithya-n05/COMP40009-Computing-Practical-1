public class GraphException extends RuntimeException{

	public GraphException(String s){
		super(s);
	}
	
}