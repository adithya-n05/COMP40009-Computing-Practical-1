package aeroplane;

public class AeroplaneFullException extends Exception {

	private static final long serialVersionUID = 1L;

}
