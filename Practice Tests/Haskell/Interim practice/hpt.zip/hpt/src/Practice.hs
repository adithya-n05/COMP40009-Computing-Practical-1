module Practice where

isPrefix :: String -> String -> Bool
isPrefix = undefined

removePrefix :: String -> String -> String
--Pre:
removePrefix = undefined

suffixes :: [a] -> [[a]]
suffixes = undefined

isSubstring :: String -> String -> Bool
isSubstring = undefined

findSubstrings :: String -> String -> [Int]
findSubstrings = undefined
